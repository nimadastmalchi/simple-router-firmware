Name: Nima Amir Dastmalchi
UID: 505320372
Additional Libraries: None
Online tutorials/resources: None
